import 'package:flutter/material.dart';
import 'package:jitox_agro_app/Constants/colors.dart';
import 'package:jitox_agro_app/Constants/text_styles.dart';
import 'package:jitox_agro_app/View/Screens/Auth/login_screen.dart';
import 'package:jitox_agro_app/View/Screens/Auth/otp_verification_screen.dart';
import 'package:jitox_agro_app/View/Screens/Auth/register_screen.dart';
import 'package:responsive_sizer/responsive_sizer.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  int currentStep = 3;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 4.w),
        child: Column(
          children: [
            SizedBox(height: kToolbarHeight / 1.5),
            StepProgressIndicator(
              totalSteps: 3,
              currentStep: currentStep,
            ),
            topSection(
              currentStep == 1
                  ? "Register Account to"
                  : currentStep == 2
                      ? "Welcome Back to"
                      : "Verify your Email Id",
              currentStep == 1
                  ? "Hello there, Register to continue"
                  : currentStep == 2
                      ? "Hello there, Login to continue"
                      : "Please verify your email by clicking the link in the\nemail we’ve sent you.",
              currentStep != 3,
            ),
            // RegisterScreen(),
            // LoginScreen(),
            OtpVerificationScreen(),
          ],
        ),
      ),
    );
  }
}

class StepProgressIndicator extends StatelessWidget {
  final int totalSteps;
  final int currentStep;

  const StepProgressIndicator({
    Key? key,
    required this.totalSteps,
    required this.currentStep,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 4.h,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: List.generate(totalSteps * 2 - 1, (index) {
          if (index.isEven) {
            int dotIndex = index ~/ 2;
            return Container(
              width: 1.5.h,
              height: 1.5.h,
              decoration: BoxDecoration(
                color:
                    dotIndex + 1 <= currentStep ? primaryColor : Colors.white,
                border: Border.all(
                    color: primaryColor,
                    width: dotIndex + 1 <= currentStep ? 0 : 1),
                shape: BoxShape.circle,
                gradient: dotIndex + 1 <= currentStep
                    ? LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          primaryColor,
                          const Color.fromARGB(255, 102, 205, 106),
                        ],
                      )
                    : null,
              ),
            );
          } else {
            return Padding(
              padding: EdgeInsets.symmetric(horizontal: 1.w),
              child: Container(
                width: 4.h,
                height: 0.1.h,
                color: primaryColor,
              ),
            );
          }
        }),
      ),
    );
  }
}

Widget topSection(String title, String message, [bool showAppName = true]) {
  return Column(
    children: [
      SizedBox(height: 2.h),
      Text(
        title,
        style: TextStyle(fontSize: 19.sp, fontWeight: FontWeight.w600),
      ),
      !showAppName
          ? Container()
          : Column(
              children: [
                Text(
                  'Jitox Agro',
                  style: authScreensTitle,
                ),
                SizedBox(height: 1.h),
              ],
            ),
      Text(
        message,
        textAlign: TextAlign.center,
        style: authScreenMessage,
      ),
      SizedBox(height: 1.h),
    ],
  );
}
