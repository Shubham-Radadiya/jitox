import 'package:flutter/material.dart';
import 'package:jitox_agro_app/Constants/colors.dart';

class CustomButton extends StatelessWidget {
  final String text;
  final VoidCallback onPressed;
  final bool isOutlined;
  final Color? outlineColor;

  const CustomButton({
    Key? key,
    required this.text,
    required this.onPressed,
    required this.isOutlined,
    this.outlineColor,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: isOutlined ? Colors.white : primaryColor,
        elevation: 0,
        side: isOutlined
            ? BorderSide(color: outlineColor ?? Colors.black, width: 1)
            : BorderSide.none,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
      ),
      onPressed: onPressed,
      child: Text(
        text,
        style: TextStyle(
          color: isOutlined ? outlineColor ?? Colors.black : Colors.white,
          fontSize: 16,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }
}
