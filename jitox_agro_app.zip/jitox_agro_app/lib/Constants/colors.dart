import 'package:flutter/material.dart';

const Color primaryColor = Color(0xFF0A9242);
Color lightFontColor = Color(0xFF000000).withOpacity(0.5);
